`include "src/alu_adder.sv"
`include "src/alu.sv"
`include "src/alures_mux.sv"
`include "src/control_unit.sv"
`include "src/ex_mem_reg.sv"
`include "src/id_ex_reg.sv"
`include "src/if_id_reg.sv"
`include "src/instr_mem.sv"
`include "src/mem_wb_reg.sv"
`include "src/pc_reg.sv"
`include "src/reg_file.sv"
`include "src/sign12to64.sv"
`include "src/sign32to64.sv"
`include "src/srcb_mux.sv"


module datapath import common::*;(
    input logic clk,
    input logic reset,
    input logic [63:0] PCINIT,

    input ibus_resp_t ibus_resp,
    output ibus_req_t ibus_req,

    output logic [31:0] test_instr,
    output logic [63:0] test_pc,
    output logic test_wen,
    output logic [4:0] test_wdest,
    output logic [63:0] test_wdata,

    output logic valid,
    output logic [63:0] test_reg_x0,
    output logic [63:0] test_reg_x1,
    output logic [63:0] test_reg_x2,
    output logic [63:0] test_reg_x3,
    output logic [63:0] test_reg_x4,
    output logic [63:0] test_reg_x5,
    output logic [63:0] test_reg_x6,
    output logic [63:0] test_reg_x7,
    output logic [63:0] test_reg_x8,
    output logic [63:0] test_reg_x9,
    output logic [63:0] test_reg_x10,
    output logic [63:0] test_reg_x11,
    output logic [63:0] test_reg_x12,
    output logic [63:0] test_reg_x13,
    output logic [63:0] test_reg_x14,
    output logic [63:0] test_reg_x15,
    output logic [63:0] test_reg_x16,
    output logic [63:0] test_reg_x17,
    output logic [63:0] test_reg_x18,
    output logic [63:0] test_reg_x19,
    output logic [63:0] test_reg_x20,
    output logic [63:0] test_reg_x21,
    output logic [63:0] test_reg_x22,
    output logic [63:0] test_reg_x23,
    output logic [63:0] test_reg_x24,
    output logic [63:0] test_reg_x25,
    output logic [63:0] test_reg_x26,
    output logic [63:0] test_reg_x27,
    output logic [63:0] test_reg_x28,
    output logic [63:0] test_reg_x29,
    output logic [63:0] test_reg_x30,
    output logic [63:0] test_reg_x31
);


    // 1 IF
    logic fetch_ok;
    logic valid_d;
    logic valid_e;
    logic valid_m;

    logic [31:0] instr_f;
    logic [31:0] instr_d;
    logic [31:0] instr_e;
    logic [31:0] instr_m;
    logic [31:0] instr_w;

    logic [63:0] pc_f;
    logic [63:0] pc_d;
    logic [63:0] pc_e;
    logic [63:0] pc_m;
    logic [63:0] pc_w;

    logic fetch_consume;
    assign fetch_consume = fetch_ok;

    instr_mem if3(
        .clk        (clk),
        .reset      (reset),
        .consume    (fetch_consume),
        .ibus_resp  (ibus_resp),
        .pcinit     (PCINIT),

        .fetch_ok   (fetch_ok),
        .instr      (instr_f),
        .ibus_req   (ibus_req),
        .instr_pc   (pc_f)
    );

    //IF/ID
    if_id_reg if_id(
        .instr_f    (instr_f),
        .clk        (clk),
        .reset      (reset),
        .fetch_ok   (fetch_ok),
        .instr_d    (instr_d),
        .pc_d       (pc_d),
        .pc_f       (pc_f),
        .valid_d    (valid_d)
    );

    // 2 ID
    logic [2:0]     funct3;
    logic [6:0]     funct7;
    logic [11:0]    immediate;
    logic [4:0]     rs1;
    logic [4:0]     rs2;
    logic [4:0]     rd;
    logic [6:0]     opcode;
    logic [63:0]    imm_d;

    logic           alusign_d;
    logic           memwrite_d;
    logic [2:0]     aluctrl_d;
    logic           alusrc_d;
    logic           regwrite_d;

    assign opcode    = instr_d[6:0];
    assign rd        = instr_d[11:7];
    assign funct3    = instr_d[14:12];
    assign rs1       = instr_d[19:15];
    assign rs2       = instr_d[24:20];
    assign funct7    = instr_d[31:25];
    assign immediate = instr_d[31:20];

    control_unit ID1(
        .funct3         (funct3),
        .funct7         (funct7),
        .opcode         (opcode),
        .alusign_d      (alusign_d),
        .memwrite_d     (memwrite_d),
        .aluctrl_d      (aluctrl_d),
        .alusrc_d       (alusrc_d),
        .regwrite_d     (regwrite_d)
    );

    logic [63:0] rs1_val_d;
    logic [63:0] rs2_val_d;
    logic [63:0] aluout_w;
    logic [4:0]  rd_w;
    logic        regwrite_w;

    reg_file ID2(
        .rs1            (rs1),
        .rs2            (rs2),
        .writedata      (aluout_w),
        .rd             (rd_w),
        .regwrite       (regwrite_w & valid),
        .clk            (clk),
        .reset          (reset),

        .rs1_val_d      (rs1_val_d),
        .rs2_val_d      (rs2_val_d),

        .test_reg_x0    (test_reg_x0),
        .test_reg_x1    (test_reg_x1),
        .test_reg_x2    (test_reg_x2),
        .test_reg_x3    (test_reg_x3),
        .test_reg_x4    (test_reg_x4),
        .test_reg_x5    (test_reg_x5),
        .test_reg_x6    (test_reg_x6),
        .test_reg_x7    (test_reg_x7),
        .test_reg_x8    (test_reg_x8),
        .test_reg_x9    (test_reg_x9),
        .test_reg_x10   (test_reg_x10),
        .test_reg_x11   (test_reg_x11),
        .test_reg_x12   (test_reg_x12),
        .test_reg_x13   (test_reg_x13),
        .test_reg_x14   (test_reg_x14),
        .test_reg_x15   (test_reg_x15),
        .test_reg_x16   (test_reg_x16),
        .test_reg_x17   (test_reg_x17),
        .test_reg_x18   (test_reg_x18),
        .test_reg_x19   (test_reg_x19),
        .test_reg_x20   (test_reg_x20),
        .test_reg_x21   (test_reg_x21),
        .test_reg_x22   (test_reg_x22),
        .test_reg_x23   (test_reg_x23),
        .test_reg_x24   (test_reg_x24),
        .test_reg_x25   (test_reg_x25),
        .test_reg_x26   (test_reg_x26),
        .test_reg_x27   (test_reg_x27),
        .test_reg_x28   (test_reg_x28),
        .test_reg_x29   (test_reg_x29),
        .test_reg_x30   (test_reg_x30),
        .test_reg_x31   (test_reg_x31)
    );
    
    sign12to64 ID3(
        .short_imm      (immediate),
        .long_imm       (imm_d)
    );

    // ID/EX
    logic [63:0] rs1_val_e;
    logic [63:0] rs2_val_e;
    logic [4:0]  rd_e;
    logic [63:0] imm_e;
    logic        alusign_e;
    logic [2:0]  aluctrl_e;
    logic        alusrc_e;
    logic        memwrite_e;
    logic        regwrite_e;

    id_ex_reg id_ex(
        .clk        (clk),
        .reset      (reset),
        .rs1_val_d  (rs1_val_d),
        .rs2_val_d  (rs2_val_d),
        .imm_d      (imm_d),
        .rd_d       (rd),
        .alusign_d  (alusign_d),
        .aluctrl_d  (aluctrl_d),
        .alusrc_d   (alusrc_d),
        .memwrite_d (memwrite_d),
        .regwrite_d (regwrite_d),
        .instr_d    (instr_d),
        .pc_d       (pc_d),
        .valid_d    (valid_d),      

        .valid_e    (valid_e),
        .instr_e    (instr_e),
        .pc_e       (pc_e),
        .rs1_val_e  (rs1_val_e),
        .rs2_val_e  (rs2_val_e),
        .imm_e      (imm_e),
        .rd_e       (rd_e),
        .alusign_e  (alusign_e),
        .aluctrl_e  (aluctrl_e),
        .alusrc_e   (alusrc_e),
        .memwrite_e (memwrite_e),
        .regwrite_e (regwrite_e)
    );

    // 3. EX
    logic [63:0] srcb_e;
    logic [63:0] srca_e;
    logic [63:0] alu_result_e;
    logic [63:0] long_alu_result_e;

    assign srca_e = rs1_val_e;

    srcb_mux EX1(
        .imm_e      (imm_e),
        .rs2_val_e  (rs2_val_e),
        .alusrc_e   (alusrc_e),
        .srcb_e     (srcb_e)
    );  

    alu EX2(
        .srca_e         (srca_e),
        .srcb_e         (srcb_e),
        .aluctrl_e      (aluctrl_e),
        .alu_result_e   (alu_result_e)
    );

    sign32to64 EX3(
        .short_imm      (alu_result_e),
        .long_imm       (long_alu_result_e)
    );

    logic [63:0] aluout_e;
    alures_mux EX4(
        .alusign_e          (alusign_e),
        .alu_result_e       (alu_result_e),
        .long_alu_result_e  (long_alu_result_e),
        .final_alu_result_e (aluout_e)
    );

    // EX/MEM
    logic        memwrite_m;
    logic [63:0] aluout_m;
    logic [4:0]  rd_m;
    logic        regwrite_m;

    ex_mem_reg ex_mem(
        .memwrite_e         (memwrite_e),
        .final_alu_result_e (aluout_e),
        .rd_e               (rd_e),
        .clk                (clk),
        .reset              (reset),
        .regwrite_e         (regwrite_e),
        .instr_e            (instr_e),
        .pc_e               (pc_e),
        .valid_e            (valid_e),

        .valid_m            (valid_m),
        .instr_m            (instr_m),
        .pc_m               (pc_m),
        .memwrite_m         (memwrite_m),
        .final_alu_result_m (aluout_m),
        .rd_m               (rd_m),
        .regwrite_m         (regwrite_m)
    );

    // 4. MEM

    // MEM/WB
    mem_wb_reg mem_wb(
        .aluout_m       (aluout_m),
        .rd_m           (rd_m),
        .clk            (clk),
        .reset          (reset),
        .regwrite_m     (regwrite_m),
        .instr_m        (instr_m),
        .pc_m           (pc_m),
        .valid_m        (valid_m),

        .valid_w        (valid),
        .instr_w        (instr_w),
        .pc_w           (pc_w),
        .aluout_w       (aluout_w),
        .rd_w           (rd_w),
        .regwrite_w     (regwrite_w)
    );

    // 5. WB (提交对齐 gpt)
    logic        commit_valid;
    logic [63:0] commit_pc;
    logic [31:0] commit_instr;
    logic        commit_wen;
    logic [4:0]  commit_wdest;
    logic [63:0] commit_wdata;

    always_ff @(posedge clk) begin
        if (reset) begin
            commit_valid <= 1'b0;
            commit_pc    <= 64'b0;
            commit_instr <= 32'b0;
            commit_wen   <= 1'b0;
            commit_wdest <= 5'b0;
            commit_wdata <= 64'b0;
        end else begin
            commit_valid <= valid;
            commit_pc    <= pc_w;
            commit_instr <= instr_w;
            commit_wen   <= regwrite_w;
            commit_wdest <= rd_w;
            commit_wdata <= aluout_w;
        end
    end

    assign test_pc    = commit_pc;
    assign test_instr = commit_instr;
    assign test_wen   = commit_wen & commit_valid;
    assign test_wdest = commit_wdest;
    assign test_wdata = commit_wdata;

endmodule