//模块名称：control_unit
//接口：input logic [2:0] funct3
//     input logic [6:0] funct7
//     input logic [6:0] opcode
//     output logic alusign_d
//     output logic memwrite_d
//     output logic [2:0] aluctrl_d
//     output logic alusrc_d
//     output logic regwrite_d
//功能：将指令编码翻译成控制信号。控制信号默认为0。
//当opcode为0010011时，将alusrc_d写为1，memwrite_d写为0，alusign_d写为0，regwrite_d写为1
//在此基础上，当funct3为000时，将aluctrl_d写为0。
//           当funct3为100时，将aluctrl_d写为1。
//           当funct3为110时，将aluctrl_d写为2。
//           当funct3为111时，将aluctrl_d写为3。

//当opcode为0110011时，将alusrc_d写为0，memwrite_d写为0，alusign_d写为0，regwrite_d写为1
//在此基础上，当funct3为000，且funct7为0000000时，将aluctrl_d写为0。
//           当funct3为000，且funct7为0100000时，将aluctrl_d写为4。
//           当funct3为100时，将aluctrl_d写为1。
//           当funct3为110时，将aluctrl_d写为2。
//           当funct3为111时，将aluctrl_d写为3。

//当opcode为0011011时，将alusrc_d写为1，memwrite_d写为0，alusign_d写为1，regwrite_d写为1
//在此基础上，当funct3为000时，将aluctrl_d写为0。

//当opcode为0111011时，将alusrc_d写为0，memwrite_d写为0，alusign_d写为1，regwrite_d写为1
//在此基础上，当funct3为000，且funct7为0000000时，将aluctrl_d写为0。
//           当funct3为000，且funct7为0100000时，将aluctrl_d写为4。

module control_unit(
    input  logic [2:0] funct3,
    input  logic [6:0] funct7,
    input  logic [6:0] opcode,
    output logic       alusign_d,
    output logic       memwrite_d,
    output logic [2:0] aluctrl_d,
    output logic       alusrc_d,
    output logic       regwrite_d
);

    always_comb begin
        // 默认值
        alusign_d  = 1'b0;
        memwrite_d = 1'b0;
        aluctrl_d  = 3'd0;
        alusrc_d   = 1'b0;
        regwrite_d = 1'b0;

        case (opcode)
            7'b0010011: begin
                // I-type
                alusrc_d   = 1'b1;
                memwrite_d = 1'b0;
                alusign_d  = 1'b0;
                regwrite_d = 1'b1;

                case (funct3)
                    3'b000: aluctrl_d = 3'd0;
                    3'b100: aluctrl_d = 3'd1;
                    3'b110: aluctrl_d = 3'd2;
                    3'b111: aluctrl_d = 3'd3;
                    default: aluctrl_d = 3'd0;
                endcase
            end

            7'b0110011: begin
                // R-type
                alusrc_d   = 1'b0;
                memwrite_d = 1'b0;
                alusign_d  = 1'b0;
                regwrite_d = 1'b1;

                case (funct3)
                    3'b000: begin
                        if (funct7 == 7'b0000000)
                            aluctrl_d = 3'd0;
                        else if (funct7 == 7'b0100000)
                            aluctrl_d = 3'd4;
                        else
                            aluctrl_d = 3'd0;
                    end
                    3'b100: aluctrl_d = 3'd1;
                    3'b110: aluctrl_d = 3'd2;
                    3'b111: aluctrl_d = 3'd3;
                    default: aluctrl_d = 3'd0;
                endcase
            end

            7'b0011011: begin
                // I-type word
                alusrc_d   = 1'b1;
                memwrite_d = 1'b0;
                alusign_d  = 1'b1;
                regwrite_d = 1'b1;

                case (funct3)
                    3'b000: aluctrl_d = 3'd0;
                    default: aluctrl_d = 3'd0;
                endcase
            end

            7'b0111011: begin
                // R-type word
                alusrc_d   = 1'b0;
                memwrite_d = 1'b0;
                alusign_d  = 1'b1;
                regwrite_d = 1'b1;

                case (funct3)
                    3'b000: begin
                        if (funct7 == 7'b0000000)
                            aluctrl_d = 3'd0;
                        else if (funct7 == 7'b0100000)
                            aluctrl_d = 3'd4;
                        else
                            aluctrl_d = 3'd0;
                    end
                    default: aluctrl_d = 3'd0;
                endcase
            end

            default: begin
                alusrc_d   = 1'b0;
                memwrite_d = 1'b0;
                alusign_d  = 1'b0;
                aluctrl_d  = 3'd0;
                regwrite_d = 1'b0;
            end
        endcase
    end
endmodule