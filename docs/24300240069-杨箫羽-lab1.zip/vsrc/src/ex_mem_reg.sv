//模块名称：ex_mem_reg
//接口：input logic memwrite_e
//     input logic [63:0] final_alu_result_e
//     input logic [4:0] rd_e
//     input logic regwrite_e
//     input logic clk
//     input logic reset
//     input logic [63:0] pc_e 
//     input logic [31:0] instr_e 
//     input logic valid_e
//     output logic valid_m
//     output logic [63:0] pc_m
//     output logic [31:0] instr_m
//     output logic memwrite_m
//     output logic [63:0] final_alu_result_m
//     output logic [4:0] rd_m
//     output logic regwirte_m
//功能：流水寄存器，reset清零。每一拍将输入的“e”类量写入对应的“m”类量

module ex_mem_reg(
    input  logic        memwrite_e,
    input  logic [63:0] final_alu_result_e,
    input  logic [4:0]  rd_e,
    input  logic        clk,
    input  logic        reset,
    input  logic        regwrite_e,
    input  logic [63:0] pc_e,
    input  logic [31:0] instr_e,
    input  logic        valid_e,

    output logic        valid_m,
    output logic [63:0] pc_m,
    output logic [31:0] instr_m,
    output logic        memwrite_m,
    output logic [63:0] final_alu_result_m,
    output logic [4:0]  rd_m,
    output logic        regwrite_m
);

    always_ff @(posedge clk) begin
        if (reset) begin
            memwrite_m         <= 1'b0;
            final_alu_result_m <= 64'b0;
            rd_m               <= 5'b0;
            pc_m               <= 64'b0;
            instr_m            <= 32'b0;
            valid_m            <= 1'b0;
            regwrite_m         <= 1'b0;
        end else begin
            memwrite_m         <= memwrite_e;
            final_alu_result_m <= final_alu_result_e;
            rd_m               <= rd_e;
            pc_m               <= pc_e;
            instr_m            <= instr_e;
            valid_m            <= valid_e;
            regwrite_m         <= regwrite_e;
        end
    end

endmodule